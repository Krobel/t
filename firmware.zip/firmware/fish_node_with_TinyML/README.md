# Fish-tank node with TinyML

This sketch reads fish-tank sensors and runs embedded prediction of TAN, TOC, DOC, TN, and DN.

## Inputs used by the embedded model

The deployed fish model header expects four inputs in this order:

1. DO_F(mg/L)
2. ORP_F(mV)
3. pH_F
4. Temp_F(C)

EC is still read and transmitted by the firmware, but it is not used by the deployed fish model header included here.

## Required files in this Arduino sketch folder

- `fish_node_with_TinyML.ino`
- `fish_compact_models.h`

## Important correction

The uploaded fish firmware originally passed five inputs, including EC, into the deployed fish model. The included repository version was corrected to match `fish_compact_models.h`, which defines `FISH_N_FEATURES` as 4.
