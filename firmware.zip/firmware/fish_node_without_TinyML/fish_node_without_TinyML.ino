// WATER QUALITY MONITORING SYSTEM
// Biofloc-based recirculating aquaculture system
// ESP32-S3 + Notecard I2C + Atlas I2C
// Sensor-only version: prediction and turbidity completely removed
// Includes runtime memory reporting: heap and PSRAM
// Includes Blues Sleepy Sensor host sleep using card.attn
// No ESP32 esp_sleep.h fallback is used

#include <Arduino.h>
#include <Wire.h>
#include <Notecard.h>
#include <Ezo_i2c.h>
#include <Ezo_i2c_util.h>

// ----------------- Board pin configuration -----------------

// I2C bus for Atlas + Notecard
#define I2C_SDA_PIN   3
#define I2C_SCL_PIN   4

// ----------------- Notecard / Atlas setup -----------------

Notecard notecard;

#ifndef PRODUCT_UID
#define PRODUCT_UID "YOUR_NOTEHUB_PRODUCT_UID"
#endif

// Notecard sync tuning
const int OUTBOUND_MINUTES = 30;
const int INBOUND_MINUTES  = 240;

// Blues Sleepy Sensor host sleep interval
const uint32_t HOST_SLEEP_SECONDS = 600;  // 10 minutes

// ----------------- Atlas sensors I2C addresses -----------------

Ezo_board ORP(0x62, "ORP");
Ezo_board DO(0x61, "DO");
Ezo_board pH(0x63, "pH");
Ezo_board Ec(0x64, "Ec");
Ezo_board atlasTemp(0x66, "Temp");

// ----------------- Globals for sensor readings -----------------

float Ec_float   = NAN;  // Atlas EC output, usually uS/cm
float Temp_float = NAN;
float pH_float   = NAN;
float DO_float   = NAN;
float ORP_float  = NAN;

String Time;

// ----------------- Globals for resource evaluation -----------------

uint32_t free_heap_bytes = 0;
uint32_t heap_size_bytes = 0;
uint32_t min_free_heap_bytes = 0;

bool psram_found = false;
uint32_t psram_total_bytes = 0;
uint32_t psram_free_bytes  = 0;
uint32_t psram_used_bytes  = 0;

// ---------------------------------------------------------------------
// Forward declarations
// ---------------------------------------------------------------------

static inline bool validNumber(double v);

void readTemperature();
void readSensors();

void updateMemoryMetrics();
void printMemoryReport();

void sendToNotecard(float ec_mS);

unsigned long getNotecardTime();
String convertEpochToTime(unsigned long epochTime);

void sleepHostWithNotecard(uint32_t seconds);

// ---------------------------------------------------------------------
// Utility
// ---------------------------------------------------------------------

static inline bool validNumber(double v) {
  return !isnan(v) && isfinite(v);
}

// ---------------------------------------------------------------------
// Setup
// ---------------------------------------------------------------------

void setup() {
  Serial.begin(115200);
  delay(2000);

  Serial.println();
  Serial.println("ESP32-S3 sensor-only node starting...");
  Serial.println("Prediction code removed.");
  Serial.println("Turbidity code removed.");
  Serial.println("Runtime memory reporting enabled.");
  Serial.println("Blues Sleepy Sensor mode enabled.");

  // I2C for Atlas + Notecard
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);

  // Notecard on I2C
  notecard.begin();
  notecard.setDebugOutputStream(Serial);

  // Notecard configuration
  // ESP32 reads every 10 minutes.
  // Notecard uploads queued data every 30 minutes.
  J *req = notecard.newRequest("hub.set");

  if (req) {
    JAddStringToObject(req, "product", PRODUCT_UID);
    JAddStringToObject(req, "mode", "periodic");
    JAddNumberToObject(req, "outbound", OUTBOUND_MINUTES);
    JAddNumberToObject(req, "inbound", INBOUND_MINUTES);
    JAddBoolToObject(req, "align", true);

    if (!notecard.sendRequest(req)) {
      Serial.println("hub.set request failed.");
    } else {
      Serial.println("hub.set configured.");
    }
  } else {
    Serial.println("hub.set request allocation failed.");
  }

  updateMemoryMetrics();
  printMemoryReport();
}

// ---------------------------------------------------------------------
// Main loop
// ---------------------------------------------------------------------

void loop() {
  unsigned long epochTime = getNotecardTime();
  Time = convertEpochToTime(epochTime);

  // 1. Read Atlas sensors
  readTemperature();
  readSensors();

  // EC from Atlas is commonly uS/cm.
  // Keep both raw uS/cm and converted mS/cm.
  float ec_mS = validNumber(Ec_float) ? (Ec_float / 1000.0f) : NAN;

  Serial.println();
  Serial.println("----- Sensor reading -----");
  Serial.print("Timestamp: ");
  Serial.println(Time);

  Serial.print("EC (uS/cm): ");
  Serial.print(Ec_float, 1);

  Serial.print(" | EC (mS/cm): ");
  Serial.print(ec_mS, 3);

  Serial.print(" | Temp (C): ");
  Serial.print(Temp_float, 2);

  Serial.print(" | DO (mg/L): ");
  Serial.print(DO_float, 2);

  Serial.print(" | pH: ");
  Serial.print(pH_float, 2);

  Serial.print(" | ORP (mV): ");
  Serial.println(ORP_float, 1);

  // 2. Update and print resource report
  updateMemoryMetrics();
  printMemoryReport();

  // 3. Send sensor data and memory metrics to Notecard
  sendToNotecard(ec_mS);

  // 4. Ask the Notecard to put the host to sleep
  sleepHostWithNotecard(HOST_SLEEP_SECONDS);
}

// ---------------------------------------------------------------------
// Blues Sleepy Sensor host sleep
// ---------------------------------------------------------------------

void sleepHostWithNotecard(uint32_t seconds) {
  Serial.println();
  Serial.print("Requesting Notecard host sleep for ");
  Serial.print(seconds);
  Serial.println(" seconds...");
  Serial.flush();

  J *req = notecard.newRequest("card.attn");

  if (!req) {
    Serial.println("card.attn request allocation failed.");
    return;
  }

  JAddStringToObject(req, "mode", "sleep");
  JAddNumberToObject(req, "seconds", seconds);

  if (!notecard.sendRequest(req)) {
    Serial.println("Failed to send card.attn sleep request.");
    return;
  }

  delay(250);

  Serial.println("card.attn sleep request sent.");
  Serial.println("If Notecard ATTN is wired to ESP32-S3 EN, the host should shut down now.");
  Serial.println("If the board stays awake, check ATTN-to-EN wiring.");
  Serial.flush();

  // With correct wiring, the ESP32 should be disabled before this matters.
  // If the ESP32 remains awake, this prevents repeated readings.
  while (true) {
    delay(1000);
  }
}

// ---------------------------------------------------------------------
// Resource measurement: memory
// ---------------------------------------------------------------------

void updateMemoryMetrics() {
  free_heap_bytes = ESP.getFreeHeap();
  heap_size_bytes = ESP.getHeapSize();
  min_free_heap_bytes = ESP.getMinFreeHeap();

  psram_found = psramFound();

  if (psram_found) {
    psram_total_bytes = ESP.getPsramSize();
    psram_free_bytes  = ESP.getFreePsram();
    psram_used_bytes  = psram_total_bytes - psram_free_bytes;
  } else {
    psram_total_bytes = 0;
    psram_free_bytes  = 0;
    psram_used_bytes  = 0;
  }
}

void printMemoryReport() {
  Serial.println();
  Serial.println("===== Memory report =====");

  Serial.print("Free heap bytes: ");
  Serial.println(free_heap_bytes);

  Serial.print("Free heap kB: ");
  Serial.println(free_heap_bytes / 1024.0f, 2);

  Serial.print("Heap size bytes: ");
  Serial.println(heap_size_bytes);

  Serial.print("Heap size kB: ");
  Serial.println(heap_size_bytes / 1024.0f, 2);

  Serial.print("Minimum free heap bytes: ");
  Serial.println(min_free_heap_bytes);

  Serial.print("Minimum free heap kB: ");
  Serial.println(min_free_heap_bytes / 1024.0f, 2);

  Serial.print("PSRAM found: ");
  Serial.println(psram_found ? "Yes" : "No");

  Serial.print("PSRAM used bytes: ");
  Serial.println(psram_used_bytes);

  Serial.print("PSRAM used kB: ");
  Serial.println(psram_used_bytes / 1024.0f, 2);

  Serial.println("=========================");
}

// ---------------------------------------------------------------------
// Sensor reading functions
// ---------------------------------------------------------------------

void readTemperature() {
  atlasTemp.send_read_cmd();
  delay(600);

  if (atlasTemp.receive_read_cmd() == Ezo_board::SUCCESS) {
    Temp_float = atlasTemp.get_last_received_reading();
    Serial.print("Temperature (C): ");
    Serial.println(Temp_float, 2);
  } else {
    Serial.println("Failed to read temperature");
    Temp_float = NAN;
  }
}

void readSensors() {
  float temp_comp = (Temp_float > 0.0f && Temp_float < 100.0f) ? Temp_float : 25.0f;

  Serial.print("Compensation temperature: ");
  Serial.println(temp_comp, 2);

  Ec.send_read_with_temp_comp(temp_comp);
  delay(900);

  if (Ec.receive_read_cmd() == Ezo_board::SUCCESS) {
    Ec_float = Ec.get_last_received_reading();
  } else {
    Serial.println("Failed EC");
    Ec_float = NAN;
  }

  Serial.print("EC (uS/cm): ");
  Serial.println(Ec_float, 1);

  DO.send_read_with_temp_comp(temp_comp);
  delay(900);

  if (DO.receive_read_cmd() == Ezo_board::SUCCESS) {
    DO_float = DO.get_last_received_reading();
  } else {
    Serial.println("Failed DO");
    DO_float = NAN;
  }

  pH.send_read_with_temp_comp(temp_comp);
  delay(900);

  if (pH.receive_read_cmd() == Ezo_board::SUCCESS) {
    pH_float = pH.get_last_received_reading();
  } else {
    Serial.println("Failed pH");
    pH_float = NAN;
  }

  ORP.send_read_cmd();
  delay(900);

  if (ORP.receive_read_cmd() == Ezo_board::SUCCESS) {
    ORP_float = ORP.get_last_received_reading();
  } else {
    Serial.println("Failed ORP");
    ORP_float = NAN;
  }
}

// ---------------------------------------------------------------------
// Notecard integration
// ---------------------------------------------------------------------

void sendToNotecard(float ec_mS) {
  J *req = notecard.newRequest("note.add");

  if (!req) {
    Serial.println("note.add allocation failed.");
    return;
  }

  JAddStringToObject(req, "file", "sensors.qo");

  J *body = JCreateObject();

  if (!body) {
    Serial.println("body allocation failed.");
    notecard.deleteResponse(req);
    return;
  }

  JAddStringToObject(body, "timestamp", Time.c_str());

  // Raw sensors
  if (validNumber(Ec_float)) {
    JAddNumberToObject(body, "ec_uScm", Ec_float);
  }

  if (validNumber(ec_mS)) {
    JAddNumberToObject(body, "ec_mScm", ec_mS);
  }

  if (validNumber(Temp_float)) {
    JAddNumberToObject(body, "temp", Temp_float);
  }

  if (validNumber(DO_float)) {
    JAddNumberToObject(body, "DO", DO_float);
  }

  if (validNumber(pH_float)) {
    JAddNumberToObject(body, "pH", pH_float);
  }

  if (validNumber(ORP_float)) {
    JAddNumberToObject(body, "ORP", ORP_float);
  }

  // Runtime memory metrics
  JAddNumberToObject(body, "free_heap_kB", free_heap_bytes / 1024.0f);
  JAddNumberToObject(body, "heap_size_kB", heap_size_bytes / 1024.0f);
  JAddNumberToObject(body, "min_free_heap_kB", min_free_heap_bytes / 1024.0f);
  JAddNumberToObject(body, "psram_used_kB", psram_used_bytes / 1024.0f);

  JAddItemToObject(req, "body", body);

  if (!notecard.sendRequest(req)) {
    Serial.println("Failed to queue note on Notecard.");
  } else {
    Serial.println("Note queued on Notecard.");
  }
}

// ---------------------------------------------------------------------
// Time via Notecard
// ---------------------------------------------------------------------

unsigned long getNotecardTime() {
  J *req = notecard.newRequest("card.time");
  J *rsp = (req) ? notecard.requestAndResponse(req) : NULL;

  if (!rsp) {
    Serial.println("Failed to get time");
    return 0;
  }

  unsigned long epochTime = JGetNumber(rsp, "time");
  notecard.deleteResponse(rsp);

  return epochTime;
}

String convertEpochToTime(unsigned long epochTime) {
  if (epochTime == 0) {
    return "Invalid Time";
  }

  // Israel summer time is UTC+3.
  // Change to +2 during winter time if needed.
  epochTime += 3UL * 3600UL;

  int s = epochTime % 60;
  int m = (epochTime / 60) % 60;
  int h = (epochTime / 3600) % 24;
  int days = epochTime / 86400;

  int year = 1970;

  auto leap = [](int y) {
    return ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0));
  };

  while (days >= (leap(year) ? 366 : 365)) {
    days -= (leap(year) ? 366 : 365);
    year++;
  }

  int md[] = {
    31, 28, 31, 30, 31, 30,
    31, 31, 30, 31, 30, 31
  };

  if (leap(year)) {
    md[1] = 29;
  }

  int mon = 0;

  while (days >= md[mon]) {
    days -= md[mon];
    mon++;
  }

  int day = days + 1;

  char buf[20];

  sprintf(
    buf,
    "%04d-%02d-%02d %02d:%02d:%02d",
    year,
    mon + 1,
    day,
    h,
    m,
    s
  );

  return String(buf);
}